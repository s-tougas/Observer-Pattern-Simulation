import { Coordinate, Vector2D } from "./geometry.js";
export class Movement {
    location;
    // How fast the entity is moving and in what direction
    velocity = new Vector2D(0, 0);
    destination;
    constructor(location) {
        this.location = location;
    }
    getLocation() {
        return this.location;
    }
    setLocation(newLocation) {
        this.location = newLocation;
    }
    getVelocity() {
        return this.velocity;
    }
    setVelocity(velocity) {
        this.velocity = velocity;
    }
    getSpeed() {
        return this.velocity.magnitude();
    }
    // Sets the entity's velocity to move in the direction
    // of the destination at the given speed.
    setVelocityTowards(destination, speed) {
        this.destination = destination;
        this.setVelocity(Vector2D.fromPoints(this.getLocation(), destination).normalize().scale(speed));
    }
    isMoving() {
        return this.velocity.magnitude() !== 0;
    }
    // Updates the entity's location after one time unit
    // moving at its current velocity.
    updateLocation() {
        this.location = new Coordinate(this.location.x + this.velocity.x, this.location.y + this.velocity.y);
        if (this.destination) {
            const remainDistance = Vector2D.fromPoints(this.location, this.destination).magnitude();
            if (remainDistance <= this.getSpeed()) {
                this.location = this.destination;
                this.velocity = new Vector2D(0, 0);
            }
        }
    }
}
//# sourceMappingURL=movement.js.map