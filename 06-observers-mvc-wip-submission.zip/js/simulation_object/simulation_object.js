import { Model } from "../model.js";
export class SimulationObject {
    id;
    location;
    constructor(id, loc) {
        this.id = id;
        this.location = loc;
    }
    setLocation(loc) {
        this.location = loc;
    }
    getLocation() {
        return this.location;
    }
    broadcastInitialState() {
        Model.getInstance().notifyAddObject(this.id, this.getLocation(), this.getSprite());
    }
}
//# sourceMappingURL=simulation_object.js.map