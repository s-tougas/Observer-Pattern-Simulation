import { SimulationObject } from "./simulation_object.js";
import { Sprite } from "../sprite.js";
export function structureFactory(type, id, location) {
    switch (type) {
        case "house":
            return new House(location, id);
        default:
            throw new Error("unsupported structure type: " + type);
    }
}
export class Structure extends SimulationObject {
    constructor(loc, id) {
        super(id, loc);
    }
    nextTick() { }
}
class House extends Structure {
    constructor(loc, id) {
        super(loc, id);
    }
    getSprite() {
        return new Sprite("simpleHouse", 1);
    }
}
//# sourceMappingURL=structure.js.map