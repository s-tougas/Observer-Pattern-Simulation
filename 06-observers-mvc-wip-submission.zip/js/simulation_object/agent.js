import { SimulationObject } from "./simulation_object.js";
import { Movement } from "../movement.js";
import { Sprite } from "../sprite.js";
import { Model } from "../model.js";
export function agentFactory(type, id, initialLocation) {
    switch (type) {
        case "simple_lobster":
            return new SimpleLobster(initialLocation, id);
        case "sleepy_lobster":
        case "sleeping_lobster":
            return new SleepingLobster(initialLocation, id);
        default:
            throw new Error("unsupported agent type: " + type);
    }
}
export class Agent extends SimulationObject {
    // TASK: Decide whether startMoving should be abstract or not.
    movement;
    constructor(loc, id) {
        super(id, loc);
    }
    startMoving(destination, speed) {
        this.movement = new Movement(this.getLocation());
        this.movement.setVelocityTowards(destination, speed);
    }
    nextTick() {
        if (this.movement && this.movement.isMoving()) {
            this.movement.updateLocation();
            this.setLocation(this.movement.getLocation());
            Model.getInstance().notifyLocationChange(this.id, this.getLocation());
            if (!this.movement.isMoving()) {
                this.movement = undefined;
            }
        }
    }
}
class SimpleLobster extends Agent {
    constructor(loc, id) {
        super(loc, id);
    }
    getSprite() {
        return new Sprite("lobsterRegular", 0.4);
    }
}
class SleepingLobster extends SimpleLobster {
    isAsleep = false;
    hasMoved = false;
    startMoving(destination, speed) {
        if (this.isAsleep)
            return;
        super.startMoving(destination, speed);
        this.hasMoved = true;
    }
    nextTick() {
        if (!this.isAsleep) {
            super.nextTick();
            if (this.hasMoved && (!this.movement || !this.movement.isMoving())) {
                this.isAsleep = true;
                Model.getInstance().notifySpriteChange(this.id, this.getSprite());
            }
        }
    }
    getSprite() {
        if (this.isAsleep) {
            return new Sprite("lobsterSleeping", 0.25);
        }
        return super.getSprite();
    }
}
//# sourceMappingURL=agent.js.map