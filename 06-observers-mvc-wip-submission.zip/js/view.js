export class View {
    updateSpriteChanged(simulationObjectId, sprite) { }
}
export class MainSimulationView extends View {
    canvas;
    // Map of object id to drawable object
    // Keep this map up to date when this view recieves updates
    // from the model.
    drawableObjects = new Map();
    constructor(canvas) {
        super();
        this.canvas = canvas;
    }
    // The draw method is provided for you.
    // It draws each drawable object on the canvas.
    draw() {
        for (const drawable of this.drawableObjects.values()) {
            this.canvas.getContext("2d")?.drawImage(drawable.getSpriteImage(), 
            // Use integer pixels for efficiency.
            // https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API/Tutorial/Optimizing_canvas#avoid_floating-point_coordinates_and_use_integers_instead
            Math.floor(drawable.location.x), Math.floor(drawable.location.y), Math.floor(drawable.getSpriteImage().width * drawable.getSprite().scale), Math.floor(drawable.getSpriteImage().height * drawable.getSprite().scale));
        }
    }
    updateSimulationObjectAdded(simulationObjectId, location, sprite) {
        const drawable = new DrawableSimulationObject(simulationObjectId, location, sprite);
        this.drawableObjects.set(simulationObjectId, drawable);
    }
    updateLocationChanged(simulationObjectId, location) {
        const drawable = this.drawableObjects.get(simulationObjectId);
        if (drawable !== undefined) {
            drawable.location = location;
        }
    }
    updateSpriteChanged(simulatedObjectId, sprite) {
        const drawable = this.drawableObjects.get(simulatedObjectId);
        if (drawable !== undefined) {
            drawable.setSprite(sprite);
        }
    }
}
// Stores information needed to draw a simulation object.
class DrawableSimulationObject {
    id;
    location;
    sprite;
    loadedImage;
    constructor(id, location, sprite) {
        this.id = id;
        this.location = location;
        this.sprite = sprite;
        this.loadedImage = document.getElementById(sprite.imageID);
    }
    getSprite() {
        return this.sprite;
    }
    getSpriteImage() {
        return this.loadedImage;
    }
    setSprite(sprite) {
        this.sprite = sprite;
        this.loadedImage = document.getElementById(sprite.imageID);
    }
}
//# sourceMappingURL=view.js.map