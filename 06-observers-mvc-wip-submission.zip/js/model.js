export class Model {
    structures = new Map();
    agents = new Map();
    views = [];
    static instance;
    constructor() { }
    // Implement this method according to the singleton pattern seen in class
    static getInstance() {
        if (!Model.instance) {
            Model.instance = new Model();
        }
        return Model.instance;
    }
    // Call next tick on every simulation object
    nextTick() {
        for (const agent of this.agents.values()) {
            agent.nextTick();
        }
        for (const structure of this.structures.values()) {
            structure.nextTick();
        }
    }
    notifyAddObject(id, location, sprite) {
        for (const view of this.views) {
            view.updateSimulationObjectAdded(id, location, sprite);
        }
    }
    notifyLocationChange(id, location) {
        for (const view of this.views) {
            view.updateLocationChanged(id, location);
        }
    }
    notifySpriteChange(id, sprite) {
        for (const view of this.views) {
            view.updateSpriteChanged(id, sprite);
        }
    }
    // Add the given agent to the simulation and ask it to broadcast
    // its initial state.
    // The behavior is unspecified if an agent with the same ID already exists.
    addAgent(agent) {
        this.agents.set(agent.id, agent);
        agent.broadcastInitialState();
    }
    // Return the agent with the specified id.
    // The behavior is unspecified if no agent with that id exists.
    getAgent(id) {
        const desiredAgent = this.agents.get(id);
        if (!desiredAgent)
            throw new Error("Agent not found");
        return desiredAgent;
    }
    // Add the given structure to the simulation and ask it to broadcast
    // its initial state.
    // The behavior is unspecified if a structure with the same ID already exists.
    addStructure(structure) {
        this.structures.set(structure.id, structure);
        structure.broadcastInitialState();
    }
    // Subscribe the given view to recieve updates from the model
    attach(view) {
        this.views.push(view);
    }
}
//# sourceMappingURL=model.js.map