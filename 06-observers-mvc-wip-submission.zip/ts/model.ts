import type { Agent } from "./simulation_object/agent.js";
import type { Structure } from "./simulation_object/structure.js";
import type { View } from "./view.js";
import type { Sprite } from "./sprite.js";
import type { Coordinate } from "./geometry.js";

export class Model {
  private structures = new Map<string, Structure>();
  private agents = new Map<string, Agent>();

  private views: View[] = [];

  private static instance?: Model | undefined;

  private constructor() {}
  // Implement this method according to the singleton pattern seen in class
  static getInstance(): Model {
    if (!Model.instance) {
      Model.instance = new Model();
    }
    return Model.instance;
  }

  // Call next tick on every simulation object
  public nextTick() {
    for (const agent of this.agents.values()) {
      agent.nextTick();
    }

    for (const structure of this.structures.values()) {
      structure.nextTick();
    }
  }
  public notifyAddObject(id: string, location: Coordinate, sprite: Sprite) {
    for (const view of this.views) {
      view.updateSimulationObjectAdded(id, location, sprite);
    }
  }
  public notifyLocationChange(id: string, location: Coordinate) {
    for (const view of this.views) {
      view.updateLocationChanged(id, location);
    }
  }
  public notifySpriteChange(id: string, sprite: Sprite) {
    for (const view of this.views) {
      view.updateSpriteChanged(id, sprite);
    }
  }
  // Add the given agent to the simulation and ask it to broadcast
  // its initial state.
  // The behavior is unspecified if an agent with the same ID already exists.
  public addAgent(agent: Agent) {
    this.agents.set(agent.id, agent);
    agent.broadcastInitialState();
  }

  // Return the agent with the specified id.
  // The behavior is unspecified if no agent with that id exists.
  public getAgent(id: string): Agent {
    const desiredAgent = this.agents.get(id);

    if (!desiredAgent) throw new Error("Agent not found");
    return desiredAgent;
  }

  // Add the given structure to the simulation and ask it to broadcast
  // its initial state.
  // The behavior is unspecified if a structure with the same ID already exists.
  public addStructure(structure: Structure) {
    this.structures.set(structure.id, structure);
    structure.broadcastInitialState();
  }

  // Subscribe the given view to recieve updates from the model
  public attach(view: View) {
    this.views.push(view);
  }
}
